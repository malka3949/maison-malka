# PRD Template & Quality Checks

Always use this structure, in this order.

# PRD: [Project Name]

## 1. Overview

Write 2-3 sentences.

Include:
- What the product is
- What problem it solves
- Who it is for

Avoid marketing language.

Do not use:
- revolutionary
- seamless
- game-changing
- innovative
- world-class

## 2. Goals

Write 3-5 bullet points.

Each goal must be specific and measurable in principle.

Bad:
- Make users happy.

Good:
- Let a user log a workout in under 30 seconds.

## 3. Target User

Describe one primary persona in no more than three lines.

Include:
- Who they are
- What they are trying to accomplish
- What currently blocks them

If there are two genuinely distinct user types, describe both only if their needs differ significantly.

Otherwise, use one persona.

## 4. User Stories

Write 5-10 user stories.

Each story must follow this exact format:

### US-[NUMBER]: [Short title]

**Story:** As a [user type], I want to [action] so that [outcome].

**Acceptance Criteria:**
- [ ] Specific, verifiable criterion
- [ ] Specific, verifiable criterion
- [ ] Specific, verifiable criterion

Rules:

- Each story must have 3-5 acceptance criteria.
- Every criterion must describe observable behavior.
- A tester must be able to verify every criterion.
- Do not write vague criteria.
- Do not use “works correctly.”
- Do not use “etc.”
- Do not use “and so on.”
- Avoid vague verbs such as “handle,” “manage,” “support,” or “process” unless the observable behavior is specified.

Good criterion:
- When the user submits an empty required field, an error message appears below that field.

Bad criterion:
- The form validates input.

## 5. Functional Requirements

Write 3-8 numbered requirements.

Format:

- FR-1: The system must [specific behavior].
- FR-2: When [condition], the system must [specific response].

These are system-level product behaviors not already covered by the user stories.

Keep this section short.

Do not add technical implementation details.

## 6. Out of Scope / Non-Goals

This section is mandatory.

List 3-7 things the project explicitly does not include.

Be strict. This section prevents scope creep.

Examples:
- User-to-user messaging is out of scope for the MVP.
- Payment collection is out of scope for the MVP.
- Admin analytics dashboards are out of scope for the MVP.

Do not include technical exclusions like databases, APIs, infrastructure, or frameworks unless the user explicitly tried to include them.

## 7. Success Criteria

Write up to 5 bullets.

These are concrete signals that the system fulfills its purpose.

They are not business KPIs.

Good:
- A first-time user can complete the primary flow without external instructions.
- The user can recover from a required-field error and resubmit successfully.

Bad:
- Increase revenue by 20%.
- Become the market leader.

## 8. Open Questions

List unresolved product questions.

If there are no open questions, write:

None at this stage.

Do not invent open questions just to fill the section.

---

# Silent Quality Checks

Before showing any draft or final PRD, silently verify:

- No mention of databases, schemas, tables, fields, or data models
- No mention of programming languages, frameworks, or libraries
- No mention of architecture, APIs, endpoints, or infrastructure
- Every user story has at least 3 acceptance criteria
- Every acceptance criterion is observable
- The Out of Scope section has at least 3 items
- No story uses “etc.” or “and so on”
- No criterion uses vague verbs unless the observable behavior is specified
- The PRD does not add features the user did not ask for
- The PRD is concise and implementation-ready

If any check fails, fix the PRD before showing it.
